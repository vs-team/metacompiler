using System.Collections.Generic;
using System.Linq;
namespace Binary_numbers {
 public static class Extensions { public static V GetKey<T, V>(this System.Collections.Immutable.ImmutableDictionary<T, V> self, T key) { return self[key]; } }
 public interface IRunnable { IEnumerable<IRunnable> Run();
IEnumerable<IRunnable> Run0_();
IEnumerable<IRunnable> Run0_2_();
 }


public interface Digit : IRunnable {}
public interface Expr : IRunnable {}
public interface Num : Expr {}



public class _opAddition : Expr {
public Num P1;
public Num P2;

public _opAddition(Num P1, Num P2) {this.P1 = P1; this.P2 = P2;}

  public IEnumerable<IRunnable> Run() {   
 { 
 #line 14 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var a = tmp_0.P1; var b = tmp_0.P2; 
 #line 14 ".\Content\Binary numbers\transform.mc"
if(a is Num && b is Num) { 
 #line 14 ".\Content\Binary numbers\transform.mc"
var tmp_2 = new addCarry(a as Num, b as Num, new d0());
 #line 14 ".\Content\Binary numbers\transform.mc"
foreach (var tmp_1 in tmp_2.Run0_()) { var c = tmp_1; 
 #line 14 ".\Content\Binary numbers\transform.mc"
var result = c;
 #line 14 ".\Content\Binary numbers\transform.mc"
yield return result;  } }
 } 

  }

public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
 var res = "("; 
res += P1.ToString(); 

 res += "+"; res += P2.ToString(); 

 res += ")";
 return res;
}

public override bool Equals(object other) {
 var tmp = other as _opAddition;
 if(tmp != null) return this.P1.Equals(tmp.P1) && this.P2.Equals(tmp.P2); 
 else return false; }
}

public class _Comma : Num {
public Num P1;
public Digit P2;

public _Comma(Num P1, Digit P2) {this.P1 = P1; this.P2 = P2;}


public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
 var res = "("; 
res += P1.ToString(); 

 res += ","; res += P2.ToString(); 

 res += ")";
 return res;
}

public override bool Equals(object other) {
 var tmp = other as _Comma;
 if(tmp != null) return this.P1.Equals(tmp.P1) && this.P2.Equals(tmp.P2); 
 else return false; }
}

public class addCarry : Expr {
public Num P1;
public Num P2;
public Digit P3;

public addCarry(Num P1, Num P2, Digit P3) {this.P1 = P1; this.P2 = P2; this.P3 = P3;}

  public IEnumerable<IRunnable> Run0_() {   
 { 
 #line 18 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as nil; 
 #line 18 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as nil; 
 #line 18 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d1; 
 #line 18 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 18 ".\Content\Binary numbers\transform.mc"
var result = new overflow();
 #line 18 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 21 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as nil; 
 #line 21 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as nil; 
 #line 21 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d0; 
 #line 21 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 21 ".\Content\Binary numbers\transform.mc"
var result = new nil();
 #line 21 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 24 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as _Comma; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var a = tmp_1.P1; var da = tmp_1.P2; var tmp_2 = tmp_0.P2 as _Comma; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var b = tmp_2.P1; var db = tmp_2.P2; var dr = tmp_0.P3; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if(da is Digit && db is Digit && dr is Digit) { 
 #line 24 ".\Content\Binary numbers\transform.mc"
var tmp_4 = new addDigits(da as Digit, db as Digit, dr as Digit);
 #line 24 ".\Content\Binary numbers\transform.mc"
foreach (var tmp_3 in tmp_4.Run0_2_()) { var tmp_5 = tmp_3 as _Comma; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if (tmp_5 != null) { var tmp_6 = tmp_5.P1 as _Comma; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if (tmp_6 != null) { var tmp_7 = tmp_6.P1 as nil; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if (tmp_7 != null) { var dr_Prime = tmp_6.P2; var d = tmp_5.P2; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if(a is Num && b is Num && dr_Prime is Digit) { 
 #line 24 ".\Content\Binary numbers\transform.mc"
var tmp_9 = new addCarry(a as Num, b as Num, dr_Prime as Digit);
 #line 24 ".\Content\Binary numbers\transform.mc"
foreach (var tmp_8 in tmp_9.Run0_2_()) { var res = tmp_8; 
 #line 24 ".\Content\Binary numbers\transform.mc"
if(res is Num && d is Digit) { 
 #line 24 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(res as Num, d as Digit);
 #line 24 ".\Content\Binary numbers\transform.mc"
yield return result;  } } } } } } } } } }
 } 

 foreach(var p in Run()) yield return p; }

public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
 var res = "("; 

 res += "addCarry"; res += P1.ToString(); 
res += P2.ToString(); 
res += P3.ToString(); 

 res += ")";
 return res;
}

public override bool Equals(object other) {
 var tmp = other as addCarry;
 if(tmp != null) return this.P1.Equals(tmp.P1) && this.P2.Equals(tmp.P2) && this.P3.Equals(tmp.P3); 
 else return false; }
}

public class addDigits : Expr {
public Digit P1;
public Digit P2;
public Digit P3;

public addDigits(Digit P1, Digit P2, Digit P3) {this.P1 = P1; this.P2 = P2; this.P3 = P3;}

  public IEnumerable<IRunnable> Run0_2_() {   
 { 
 #line 29 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d0; 
 #line 29 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d0; 
 #line 29 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d0; 
 #line 29 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 29 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d0()), new d0());
 #line 29 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 32 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d0; 
 #line 32 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d0; 
 #line 32 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d1; 
 #line 32 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 32 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d0()), new d1());
 #line 32 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 35 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d0; 
 #line 35 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d1; 
 #line 35 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d0; 
 #line 35 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 35 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d0()), new d1());
 #line 35 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 38 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d0; 
 #line 38 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d1; 
 #line 38 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d1; 
 #line 38 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 38 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d1()), new d0());
 #line 38 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 41 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d1; 
 #line 41 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d0; 
 #line 41 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d0; 
 #line 41 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 41 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d0()), new d1());
 #line 41 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 44 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d1; 
 #line 44 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d0; 
 #line 44 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d1; 
 #line 44 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 44 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d1()), new d0());
 #line 44 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 47 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d1; 
 #line 47 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d1; 
 #line 47 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d0; 
 #line 47 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 47 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d1()), new d0());
 #line 47 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

  
 { 
 #line 50 ".\Content\Binary numbers\transform.mc"
var tmp_0 = this; var tmp_1 = tmp_0.P1 as d1; 
 #line 50 ".\Content\Binary numbers\transform.mc"
if (tmp_1 != null) { var tmp_2 = tmp_0.P2 as d1; 
 #line 50 ".\Content\Binary numbers\transform.mc"
if (tmp_2 != null) { var tmp_3 = tmp_0.P3 as d1; 
 #line 50 ".\Content\Binary numbers\transform.mc"
if (tmp_3 != null) { 
 #line 50 ".\Content\Binary numbers\transform.mc"
var result = new _Comma(new _Comma(new nil(), new d1()), new d1());
 #line 50 ".\Content\Binary numbers\transform.mc"
yield return result;  } } }
 } 

 foreach(var p in Run0_()) yield return p; }

public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }

public override string ToString() {
 var res = "("; 

 res += "addDigits"; res += P1.ToString(); 
res += P2.ToString(); 
res += P3.ToString(); 

 res += ")";
 return res;
}

public override bool Equals(object other) {
 var tmp = other as addDigits;
 if(tmp != null) return this.P1.Equals(tmp.P1) && this.P2.Equals(tmp.P2) && this.P3.Equals(tmp.P3); 
 else return false; }
}

public class d0 : Digit {

public d0() {}


public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
return "d0";
}

public override bool Equals(object other) {
 return other is d0; 
}
}

public class d1 : Digit {

public d1() {}


public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
return "d1";
}

public override bool Equals(object other) {
 return other is d1; 
}
}

public class nil : Num {

public nil() {}


public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
return "nil";
}

public override bool Equals(object other) {
 return other is nil; 
}
}

public class overflow : Num {

public overflow() {}


public IEnumerable<IRunnable> Run() { foreach (var p in Enumerable.Range(0,0)) yield return null; }
public IEnumerable<IRunnable> Run0_() { foreach(var p in Run()) yield return p; }
public IEnumerable<IRunnable> Run0_2_() { foreach(var p in Run0_()) yield return p; }

public override string ToString() {
return "overflow";
}

public override bool Equals(object other) {
 return other is overflow; 
}
}




public class EntryPoint {
 static public IEnumerable<IRunnable> Run(bool printInput)
{
var p = new _opAddition(new _Comma(new _Comma(new _Comma(new _Comma(new nil(), new d0()), new d1()), new d1()), new d1()), new _Comma(new _Comma(new _Comma(new _Comma(new nil(), new d0()), new d0()), new d0()), new d1()));
if(printInput) System.Console.WriteLine(p.ToString());
foreach(var x in p.Run())
yield return x;
}
}

}
